import React from "react";
import { Nav } from "../Nav";
import { UserInfoComponent } from "../UserInfo";

export function App() {
  React.useEffect(() => {
    
  }, []);

  return (
    <>
      <Nav />
      <UserInfoComponent />
    </>
  );
}
